# Validation scope

tests.log is the complete current host sanitizer run, including the actual
capture worker connected to the real decoder engine and all default decoders.
Radio access and scheduling delays are simulated. This is not RF testing.

before.log and before-backlog.log are the expected failing assertions for
the v1.1.5 radio adapter under the new full-path tests. baseline.log is the
passing FSK case using the v1.0.1 adapter. Both archived adapter files are
included here for reproducibility; neither is part of the app build.

The adapters were compiled against the current shared header/types and
decoder engine. Place an archived adapter outside its original header
directory so quoted includes resolve to those shared types; mixing old and
new RtlFrame/RtlRadio struct layouts is invalid. Use tests/test_receive_decode.c
and the same compile/link options as the receive_decode target in tests/run.sh,
substituting radio-baseline.c or radio-before.c for rtl_radio.c. Run the binary
without arguments for FSK, or with `backlog` for the OOK queue test.

The first adapter passes the FSK case. The backlog regression tests the later
periodic-window feature, so it is compared to v1.1.5 rather than v1.0.1.

All 328 device decoder source files and the catalog header remain identical
to v1.0.1. UI sources are identical to v1.1.5. See audit.json. Existing bounds
and serialization tests continue to pass; catalog smoke tests do not validate
every physical transmitter. The synthetic Toyota fixture validates decoder
fields with 315 MHz metadata, not the user's particular over-the-air signal.

build.log includes the native ESP32-S3 build. Some untouched upstream device
files have compiler format warnings. symbols.log verifies all 125 imports
against both existing WirelessPi firmware API snapshots.
