// protopirate_app.c
#include "protopirate_app_i.h"

#include <furi.h>
#include <furi_hal.h>
#include "helpers/protopirate_settings.h"
#include "helpers/protopirate_storage.h"
#include "helpers/protopirate_psa_bf_host.h"
#include "helpers/protopirate_views.h"
#include "helpers/protopirate_radio.h"
#include "helpers/protopirate_plugins.h"
#include <string.h>

#define TAG "PPApp"

static void protopirate_actions_menu_callback(void* context, uint32_t index) {
    ProtoPirateApp* app = context;
    view_dispatcher_send_custom_event(app->view_dispatcher, ProtoPirateCustomEventAction0 + index);
}

static void protopirate_actions_show(ProtoPirateApp* app, uint32_t return_view) {
    if(app->actions_visible || !app->action_count) return;
    app->actions_return_view = return_view;
    app->actions_visible = true;
    submenu_reset(app->actions_menu);
    submenu_set_header(app->actions_menu, "Actions");
    for(uint8_t i = 0; i < app->action_count; ++i)
        submenu_add_item(app->actions_menu, app->actions[i].label, i,
            protopirate_actions_menu_callback, app);
    view_dispatcher_switch_to_view(app->view_dispatcher, ProtoPirateViewActions);
}

static bool protopirate_app_custom_event_callback(void* context, uint32_t event) {
    furi_check(context);
    ProtoPirateApp* app = context;
    if(event == ProtoPirateCustomEventOpenActions) {
        protopirate_actions_show(app, ProtoPirateViewWidget);
        return true;
    }
    if(event == ProtoPirateCustomEventOpenReceiverActions) {
        if(app->actions_visible) return true;
        app->txrx->idx_menu_chosen = protopirate_view_receiver_get_idx_menu(app->protopirate_receiver);
        app->action_count = 0;
        memset(app->actions, 0, sizeof(app->actions));
        if(app->txrx->history && protopirate_history_get_item(app->txrx->history)) {
            snprintf(app->actions[0].label, sizeof(app->actions[0].label), "Capture details");
            app->actions[0].event = ProtoPirateCustomEventViewReceiverOK;
            app->action_count++;
        }
        ProtoPirateAction* action = &app->actions[app->action_count++];
        snprintf(action->label, sizeof(action->label), "Configuration");
        action->event = ProtoPirateCustomEventViewReceiverConfig;
        if(app->action_count == 2) {
            action = &app->actions[app->action_count++];
            snprintf(action->label, sizeof(action->label), "Delete capture");
            action->event = ProtoPirateCustomEventViewReceiverDeleteItem;
        }
        protopirate_actions_show(app, ProtoPirateViewReceiver);
        return true;
    }
    if(event >= ProtoPirateCustomEventAction0 && event <= ProtoPirateCustomEventAction2) {
        uint32_t index = event - ProtoPirateCustomEventAction0;
        if(!app->actions_visible || index >= app->action_count) return true;
        ProtoPirateAction selected = app->actions[index];
        app->actions_visible = false;
        view_dispatcher_switch_to_view(app->view_dispatcher, app->actions_return_view);
        if(app->actions_return_view == ProtoPirateViewReceiver)
            protopirate_view_receiver_set_idx_menu(app->protopirate_receiver, app->txrx->idx_menu_chosen);
        if(selected.callback) selected.callback(selected.button, InputTypeShort, selected.context);
        else scene_manager_handle_custom_event(app->scene_manager, selected.event);
        return true;
    }
    return scene_manager_handle_custom_event(app->scene_manager, event);
}

static bool protopirate_app_back_event_callback(void* context) {
    furi_check(context);
    ProtoPirateApp* app = context;
    if(app->actions_visible) {
        app->actions_visible = false;
        view_dispatcher_switch_to_view(app->view_dispatcher, app->actions_return_view);
        return true;
    }
    if(!scene_manager_handle_back_event(app->scene_manager)) {
        scene_manager_next_scene(app->scene_manager, ProtoPirateSceneStart);
    }
    return true;
}

static void protopirate_app_tick_event_callback(void* context) {
    furi_check(context);
    ProtoPirateApp* app = context;
    scene_manager_handle_tick_event(app->scene_manager);
}

ProtoPirateApp* protopirate_app_alloc() {
    protopirate_storage_purge_temp_history_at_startup();
    ProtoPirateApp* app = malloc(sizeof(ProtoPirateApp));
    if(!app) {
        FURI_LOG_E(TAG, "Failed to allocate ProtoPirateApp app !");
        return NULL;
    }
    memset(app, 0, sizeof(ProtoPirateApp));

    FURI_LOG_I(TAG, "Allocating ProtoPirate Decoder App");

    // GUI
    app->gui = furi_record_open(RECORD_GUI);

    // View Dispatcher
    app->view_dispatcher = view_dispatcher_alloc();
#if defined(FW_ORIGIN_RM)
    view_dispatcher_enable_queue(app->view_dispatcher);
#endif
    app->scene_manager = scene_manager_alloc(&protopirate_scene_handlers, app);
    for(uint32_t scene = 0; scene < ProtoPirateSceneNum; ++scene)
        scene_manager_set_scene_state(app->scene_manager, scene, 0);

    view_dispatcher_set_event_callback_context(app->view_dispatcher, app);
    view_dispatcher_set_custom_event_callback(
        app->view_dispatcher, protopirate_app_custom_event_callback);
    view_dispatcher_set_navigation_event_callback(
        app->view_dispatcher, protopirate_app_back_event_callback);
    view_dispatcher_set_tick_event_callback(
        app->view_dispatcher, protopirate_app_tick_event_callback, 100);

    view_dispatcher_attach_to_gui(app->view_dispatcher, app->gui, ViewDispatcherTypeFullscreen);

    // Open Notification record
    app->notifications = furi_record_open(RECORD_NOTIFICATION);

    // Open Dialogs record
    app->dialogs = furi_record_open(RECORD_DIALOGS);

    // SubMenu
    app->actions_menu = submenu_alloc();
    view_dispatcher_add_view(app->view_dispatcher, ProtoPirateViewActions, submenu_get_view(app->actions_menu));
    app->submenu = submenu_alloc();
    view_dispatcher_add_view(
        app->view_dispatcher, ProtoPirateViewSubmenu, submenu_get_view(app->submenu));

    app->save_protocol = NULL;
    app->save_history_idx = 0;
    app->emulate_disabled_for_loaded = false;
    app->save_filename[0] = '\0';

    // File Browser path
    app->file_path = malloc(strlen(PROTOPIRATE_APP_FOLDER) + 1);
    snprintf(app->file_path, strlen(PROTOPIRATE_APP_FOLDER) + 1, PROTOPIRATE_APP_FOLDER);

    // Load saved settings
    ProtoPirateSettings settings;
    protopirate_settings_load(&settings);

    // Apply auto-save setting
    app->auto_save = settings.auto_save;
    app->sound = settings.sound;
    app->check_saved = settings.check_saved;
    app->tx_power = settings.tx_power;
    app->datetime_filenames = settings.datetime_filenames;
#ifdef ENABLE_EMULATE_FEATURE
    app->emulate_feature_enabled = settings.emulate_feature_enabled;
#else
    app->emulate_feature_enabled = false;
#endif

    // Init setting - KEEP THIS, it's small
    app->setting = subghz_setting_alloc();
    app->loaded_file_path = NULL;
    app->start_tx_time = 0;
    app->deferred_storage_pending = false;
    subghz_setting_load(app->setting, EXT_PATH("subghz/assets/setting_user"));

    // Apply loaded frequency and preset, with validation
    uint32_t frequency = settings.frequency;
    uint8_t preset_index = settings.preset_index;

    // Validate frequency
    bool frequency_valid = false;
    for(size_t i = 0; i < subghz_setting_get_frequency_count(app->setting); i++) {
        if(subghz_setting_get_frequency(app->setting, i) == frequency) {
            frequency_valid = true;
            break;
        }
    }
    if(!frequency_valid) {
        frequency = subghz_setting_get_default_frequency(app->setting);
        FURI_LOG_W(TAG, "Saved frequency invalid, using default: %lu", frequency);
    }

    // Validate preset index
    if(preset_index >= subghz_setting_get_preset_count(app->setting)) {
        preset_index = 0;
        FURI_LOG_W(TAG, "Saved preset index invalid, using default");
    }

    // Initialize TxRx structure with minimal setup
    app->lock = ProtoPirateLockOff;
    app->txrx = malloc(sizeof(ProtoPirateTxRx));
    furi_check(app->txrx);
    memset(app->txrx, 0, sizeof(ProtoPirateTxRx));

    app->txrx->preset = malloc(sizeof(SubGhzRadioPreset));
    furi_check(app->txrx->preset);
    app->txrx->preset->name = furi_string_alloc();
    furi_check(app->txrx->preset->name);
    app->txrx->txrx_state = ProtoPirateTxRxStateIDLE;
    app->txrx->rx_key_state = ProtoPirateRxKeyStateIDLE;
    app->txrx->protocol_registry_route = ProtoPirateProtocolRegistryRouteAMDefault;

    // Get preset name and data
    const char* preset_name = subghz_setting_get_preset_name(app->setting, preset_index);
    uint8_t* preset_data = subghz_setting_get_preset_data(app->setting, preset_index);
    size_t preset_data_size = subghz_setting_get_preset_data_size(app->setting, preset_index);

    FURI_LOG_I(
        TAG,
        "Settings: freq=%lu, preset=%s, auto_save=%d, hopping=%d",
        frequency,
        preset_name,
        settings.auto_save,
        settings.hopping_enabled);

    // Null out plugin pointers just in case.
    app->plugin_flipper_application = NULL;
    app->config_plugin = NULL;
    app->saved_info_plugin = NULL;
    app->about_plugin = NULL;
    app->plugin_flipper_application = NULL;
    app->psa_bf_plugin = NULL;
    app->tool_scene_plugin_flipper_application = NULL;
    app->tool_scene_plugin = NULL;
    app->variable_item_list = NULL;

    //Load the models database, get the count of the models for the list.
#ifdef ENABLE_MODELS_DATABASE
    if(shared_plugin_load(
           (void**)&app->plugin_flipper_application,
           (const void**)&app->config_plugin,
           ProtoPirateSharedPluginsConfig,
           NULL) &&
       app->config_plugin) {
        app->car_models_count = app->config_plugin->car_model_get_count();
    } else {
        notification_message(app->notifications, &sequence_error);
        app->car_models_count = 0;
    }
    app->selected_model = calloc(1, sizeof(ProtoPirateCarModel));
    furi_check(app->selected_model);
    app->selected_model->name = strdup("No Models in Database");
    protopirate_preset_init(app, preset_name, frequency, preset_data, preset_data_size);
    if(app->config_plugin) {
        bool model_ok = app->config_plugin->car_model_get_by_index(
            app->selected_model, settings.car_model_index, app->car_models_count, app->setting);
        app->selected_model->last_preset_index = preset_index;
        if(model_ok && app->selected_model->preset) {
            protopirate_preset_init(app,
                furi_string_get_cstr(app->selected_model->preset->name),
                app->selected_model->preset->frequency, app->selected_model->preset->data,
                app->selected_model->preset->data_size);
        }
        shared_plugin_unload((void**)&app->plugin_flipper_application, (const void**)&app->config_plugin);
    }
#else
    protopirate_preset_init(app, preset_name, frequency, preset_data, preset_data_size);
#endif

    // Apply hopping state from settings
    app->txrx->hopper_state = settings.hopping_enabled ? ProtoPirateHopperStateRunning :
                                                         ProtoPirateHopperStateOFF;
    app->txrx->hopper_idx_frequency = 0;
    app->txrx->hopper_timeout = 0;
    app->txrx->idx_menu_chosen = 0;

    app->radio_initialized = false;

    return app;
}

void protopirate_app_free(ProtoPirateApp* app) {
    furi_check(app);

    FURI_LOG_I(TAG, "=== protopirate_app_free called ===");
    FURI_LOG_D(TAG, "State: radio_initialized=%d", app->radio_initialized);

    // Save settings before exiting
    ProtoPirateSettings settings;
    settings.frequency = app->txrx->preset->frequency;
    settings.auto_save = app->auto_save;
    settings.sound = app->sound;
    settings.check_saved = app->check_saved;
    settings.tx_power = app->tx_power;
    settings.datetime_filenames = app->datetime_filenames;
    settings.hopping_enabled = (app->txrx->hopper_state != ProtoPirateHopperStateOFF);
#ifdef ENABLE_EMULATE_FEATURE
    settings.emulate_feature_enabled = app->emulate_feature_enabled;
#else
    settings.emulate_feature_enabled = false;
#endif

    //Get the selected Model, and get the preset to save.
#ifdef ENABLE_MODELS_DATABASE
    if(app->selected_model && app->selected_model->index) {
        //Get Preset Index before model was selected.
        settings.car_model_index = app->selected_model->index;
        settings.preset_index = app->selected_model->last_preset_index;
    } else {
        // Find current preset index
        settings.car_model_index = 0; //Clear the selected model.
        settings.preset_index = 0;
        const char* current_preset = furi_string_get_cstr(app->txrx->preset->name);
        for(uint8_t i = 0; i < subghz_setting_get_preset_count(app->setting); i++) {
            if(strcmp(subghz_setting_get_preset_name(app->setting, i), current_preset) == 0) {
                settings.preset_index = i;
                break;
            }
        }
    }

#endif

    FURI_LOG_I(
        TAG,
        "Saving settings: freq=%lu, preset=%u, auto_save=%d, hopping=%d, emulate=%d",
        settings.frequency,
        settings.preset_index,
        settings.auto_save,
        settings.hopping_enabled,
        settings.emulate_feature_enabled);

    protopirate_settings_save(&settings);

    protopirate_tool_scene_plugin_release(app);
#ifdef ENABLE_EMULATE_FEATURE
    protopirate_emulate_context_release(app);
#endif

    FURI_LOG_D(TAG, "Calling radio_deinit");
    protopirate_radio_deinit(app);
#ifdef ENABLE_MODELS_DATABASE
    //Free the Model Name
    if(app->selected_model->name) free(app->selected_model->name);
    app->selected_model->index = 0;

    //Free the preset information.
    if(app->selected_model->preset) {
        //Free the preset data
        if((app->selected_model)->preset->data) {
            free(app->selected_model->preset->data);
            app->selected_model->preset->data = NULL;
        }

        //Free the Preset name
        furi_string_free(app->selected_model->preset->name);

        //Free the preset.
        free(app->selected_model->preset);
        app->selected_model->preset = NULL;
    }

    //Free the Model.
    free(app->selected_model);
    app->selected_model = NULL;
#endif


    if(app->loaded_file_path) {
        FURI_LOG_D(TAG, "Freeing loaded_file_path");
        free(app->loaded_file_path);
        app->loaded_file_path = NULL;
    }

    protopirate_views_free(app);
    if(app->plugin_flipper_application) {
        flipper_application_free(app->plugin_flipper_application);
        app->plugin_flipper_application = NULL;
    }

    app->save_filename[0] = '\0';

    if(app->file_path) {
        FURI_LOG_D(TAG, "Freeing file_path");
        free(app->file_path);
        app->file_path = NULL;
    }

    if(app->save_protocol) {
        furi_string_free(app->save_protocol);
        app->save_protocol = NULL;
    }

    protopirate_psa_bf_context_release(app);

    FURI_LOG_D(TAG, "Freeing subghz_setting");
    subghz_setting_free(app->setting);

    FURI_LOG_D(TAG, "Freeing preset");
    furi_string_free(app->txrx->preset->name);
    free(app->txrx->preset);

    free(app->txrx);

    FURI_LOG_D(TAG, "Freeing view_dispatcher and scene_manager");
    view_dispatcher_free(app->view_dispatcher);
    scene_manager_free(app->scene_manager);

    FURI_LOG_D(TAG, "Closing dialogs record");
    furi_record_close(RECORD_DIALOGS);
    app->dialogs = NULL;

    FURI_LOG_D(TAG, "Closing notifications record");
    furi_record_close(RECORD_NOTIFICATION);
    app->notifications = NULL;

    FURI_LOG_D(TAG, "Closing GUI record");
    furi_record_close(RECORD_GUI);

    FURI_LOG_I(TAG, "App free complete");
    free(app);
}

int32_t protopirate_app(char* p) {
    ProtoPirateApp* protopirate_app = protopirate_app_alloc();
    if(!protopirate_app) {
        return -1;
    }

    //Stop charging while running the app.
    furi_hal_power_suppress_charge_enter();

    // Handle Command line PSF that may have been passed to us
    bool load_saved = (p && strlen(p));
    if(load_saved) {
        protopirate_app->loaded_file_path = malloc(strlen(p) + 1);
        snprintf(protopirate_app->loaded_file_path, strlen(p) + 1, "%s", p);
    }

    if(load_saved)
        scene_manager_next_scene(protopirate_app->scene_manager, ProtoPirateSceneStart);

// Open the requested file with the app menu underneath it.
#ifdef ENABLE_EMULATE_FEATURE
    scene_manager_next_scene(
        protopirate_app->scene_manager,
        (load_saved) ? ((protopirate_app->emulate_feature_enabled) ? ProtoPirateSceneEmulate :
                                                                     ProtoPirateSceneSavedInfo) :
                       ProtoPirateSceneStart);
#else
    scene_manager_next_scene(
        protopirate_app->scene_manager,
        (load_saved) ? ProtoPirateSceneSavedInfo : ProtoPirateSceneStart);
#endif
    //Pop up the beep if we are startng emulate.
    if(load_saved && protopirate_app->emulate_feature_enabled) {
        notification_message(protopirate_app->notifications, &sequence_success);
    }

    //Run the App
    view_dispatcher_run(protopirate_app->view_dispatcher);

    //Free the App and allow chargin again.
    protopirate_app_free(protopirate_app);

    //Restore Charging State
    furi_hal_power_suppress_charge_exit();
    return 0;
}
