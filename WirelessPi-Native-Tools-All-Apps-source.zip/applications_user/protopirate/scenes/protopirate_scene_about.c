// scenes/protopirate_scene_about.c
#include "../protopirate_app_i.h"
#include "../helpers/protopirate_settings.h"

static const ProtoPirateAboutSceneHostApi protopirate_about_scene_host_api = {
    .ensure_view_about = protopirate_ensure_view_about,
    .settings_load = protopirate_settings_load,
    .settings_save = protopirate_settings_save,
    .fap_version = FAP_VERSION,
};

void protopirate_scene_about_on_enter(void* context) {
    ProtoPirateApp* app = context;

    if(!shared_plugin_load(
           (void**)&app->plugin_flipper_application,
           (const void**)&app->about_plugin,
           ProtoPirateSharedPluginsAbout,
           NULL)) {
        notification_message(app->notifications, &sequence_error);
        scene_manager_previous_scene(app->scene_manager);
        return;
    }

    app->about_plugin->set_host_api(&protopirate_about_scene_host_api);
    app->about_plugin->on_enter(app);
}

bool protopirate_scene_about_on_event(void* context, SceneManagerEvent event) {
    ProtoPirateApp* app = (ProtoPirateApp*)context;

    //I can't set the next scene from inside the plugin, or it causes crazy crashes.
    if(event.type == SceneManagerEventTypeBack) {
        scene_manager_previous_scene(app->scene_manager);
        return true;
    }

    //Handle About event in plugin.
    return app->about_plugin && app->about_plugin->on_event(app, event);
}

void protopirate_scene_about_on_exit(void* context) {
    ProtoPirateApp* app = context;
    if(app->view_about) {
        view_dispatcher_remove_view(app->view_dispatcher, ProtoPirateViewAbout);
        view_free(app->view_about);
        app->view_about = NULL;
    }
    shared_plugin_unload(
        (void**)&app->plugin_flipper_application, (const void**)&app->about_plugin);
}
