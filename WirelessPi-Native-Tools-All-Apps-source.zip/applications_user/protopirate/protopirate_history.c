// protopirate_history.c
#include "protopirate_history.h"
#include "helpers/protopirate_storage.h"
#include <lib/subghz/receiver.h>
#include <storage/storage.h>
#include <string.h>
#include <stdio.h>
#include <furi.h>
#include "defines.h"
#include <lib/flipper_format/flipper_format_i.h>
#include <toolbox/stream/stream.h>

#define HISTORY_CAPTURE_MAX_BYTES 4096U
#define HISTORY_LABEL_MAX_BYTES 1024U

#define TAG                          "ProtoPirateHistory"
#define HISTORY_SCRATCH_TEXT_RESERVE 256U
#define HISTORY_SCRATCH_PATH_RESERVE 128U
#define HISTORY_ARENA_RESERVE        1024U
#define HISTORY_DUPLICATE_WINDOW     500U

typedef enum {
    ProtoPirateSavedMatchStateNone = 0,
    ProtoPirateSavedMatchStatePending,
    ProtoPirateSavedMatchStateDone,
} ProtoPirateSavedMatchState;

typedef enum {
    ProtoPirateAutoSaveStateNone = 0,
    ProtoPirateAutoSaveStatePending,
    ProtoPirateAutoSaveStateDone,
} ProtoPirateAutoSaveState;

typedef struct {
    uint32_t seq_id;
    FlipperFormat* capture; /* Owned RAM snapshot in live receive mode. */
    bool persisted;
    uint16_t text_offset;
    uint16_t text_len;
    uint8_t type;
    uint8_t saved_match_state;
    uint8_t auto_save_state;
    FuriString* matched_saved_path;
    FuriString* matched_name;
} ProtoPirateHistoryItem;

ARRAY_DEF(ProtoPirateHistoryItemArray, ProtoPirateHistoryItem, M_POD_OPLIST)

struct ProtoPirateHistory {
    FuriMutex* mutex;
    bool memory_mode;
    ProtoPirateHistoryItemArray_t data;
    uint16_t last_index;
    uint32_t last_update_timestamp;
    uint8_t code_last_hash_data;
    uint32_t next_capture_seq;
    Storage* storage;
    FlipperFormat* loaded_ff;
    int16_t loaded_idx;

    FuriString* scratch_text;
    FuriString* scratch_path;
    FuriString* text_arena;
};

/* RX, the UI event loop and the GUI draw thread share the history index.
 * Use a recursive lock because the public helpers call one another. Never hold
 * it while acquiring a view-model lock or waiting for the receive worker. */
void protopirate_history_lock(ProtoPirateHistory* instance) {
    furi_check(instance);
    furi_check(furi_mutex_acquire(instance->mutex, FuriWaitForever) == FuriStatusOk);
}

void protopirate_history_unlock(ProtoPirateHistory* instance) {
    furi_check(instance);
    furi_check(furi_mutex_release(instance->mutex) == FuriStatusOk);
}

static void protopirate_history_guard_release(ProtoPirateHistory** instance) {
    protopirate_history_unlock(*instance);
}

/* GCC/Clang scope cleanup releases the lock on every early-return path. */
#define HISTORY_GUARD(instance) \
    protopirate_history_lock(instance); \
    ProtoPirateHistory* history_guard \
        __attribute__((cleanup(protopirate_history_guard_release))) = (instance)

void protopirate_history_release_scratch(ProtoPirateHistory* instance) {
    HISTORY_GUARD(instance);
    furi_check(instance);
    if(instance->loaded_ff) {
        flipper_format_free(instance->loaded_ff);
        instance->loaded_ff = NULL;
    }
    instance->loaded_idx = -1;
}

static void
    protopirate_history_build_path(ProtoPirateHistory* instance, uint32_t seq_id, FuriString* out) {
    UNUSED(instance);
    protopirate_storage_build_history_path(seq_id, out);
}

static void
    protopirate_history_delete_capture_file(ProtoPirateHistory* instance, uint32_t seq_id) {
    protopirate_history_build_path(instance, seq_id, instance->scratch_path);
    protopirate_storage_delete_file(furi_string_get_cstr(instance->scratch_path));
}

static void protopirate_history_item_clear_matched(ProtoPirateHistoryItem* item) {
    if(!item) return;
    if(item->capture) {
        flipper_format_free(item->capture);
        item->capture = NULL;
    }
    if(item->matched_saved_path) {
        furi_string_free(item->matched_saved_path);
        item->matched_saved_path = NULL;
    }
    if(item->matched_name) {
        furi_string_free(item->matched_name);
        item->matched_name = NULL;
    }
}

static void protopirate_history_clear_all_matched(ProtoPirateHistory* instance) {
    size_t n = ProtoPirateHistoryItemArray_size(instance->data);
    for(size_t i = 0; i < n; i++) {
        ProtoPirateHistoryItem* item = ProtoPirateHistoryItemArray_get(instance->data, i);
        protopirate_history_item_clear_matched(item);
    }
}

static void
    protopirate_history_arena_remove(ProtoPirateHistory* instance, uint16_t offset, uint16_t len) {
    if(len == 0) return;

    size_t arena_size = furi_string_size(instance->text_arena);

    furi_check((size_t)offset + (size_t)len <= arena_size);

    const char* arena = furi_string_get_cstr(instance->text_arena);
    FuriString* rebuilt = furi_string_alloc();
    furi_check(rebuilt);
    furi_string_reserve(rebuilt, arena_size);
    furi_string_set_strn(rebuilt, arena, offset);
    furi_string_cat_str(rebuilt, arena + offset + len);
    furi_string_move(instance->text_arena, rebuilt);

    size_t n = ProtoPirateHistoryItemArray_size(instance->data);
    for(size_t i = 0; i < n; i++) {
        ProtoPirateHistoryItem* it = ProtoPirateHistoryItemArray_get(instance->data, i);
        if(it->text_offset > offset) {
            it->text_offset -= len;
        }
    }
}

ProtoPirateHistory* protopirate_history_alloc(void) {
    ProtoPirateHistory* instance = malloc(sizeof(ProtoPirateHistory));
    furi_check(instance);
    instance->memory_mode = false;
    instance->mutex = furi_mutex_alloc(FuriMutexTypeRecursive);
    furi_check(instance->mutex);
    ProtoPirateHistoryItemArray_init(instance->data);
    instance->last_index = 0;
    instance->last_update_timestamp = 0;
    instance->code_last_hash_data = 0;
    instance->next_capture_seq = (uint32_t)(furi_get_tick() & 0x0FFFFFFF);
    if(instance->next_capture_seq == 0) {
        instance->next_capture_seq = 1;
    }
    instance->storage = furi_record_open(RECORD_STORAGE);
    instance->loaded_ff = NULL;
    instance->loaded_idx = -1;

    instance->scratch_text = furi_string_alloc();
    furi_check(instance->scratch_text);
    furi_string_reserve(instance->scratch_text, HISTORY_SCRATCH_TEXT_RESERVE);

    instance->scratch_path = furi_string_alloc();
    furi_check(instance->scratch_path);
    furi_string_reserve(instance->scratch_path, HISTORY_SCRATCH_PATH_RESERVE);

    instance->text_arena = furi_string_alloc();
    furi_check(instance->text_arena);
    furi_string_reserve(instance->text_arena, HISTORY_ARENA_RESERVE);

    return instance;
}

void protopirate_history_enable_memory(ProtoPirateHistory* instance) {
    HISTORY_GUARD(instance);
    instance->memory_mode = true;
}

void protopirate_history_free(ProtoPirateHistory* instance) {
    furi_check(instance);
    protopirate_history_release_scratch(instance);
    protopirate_history_clear_all_matched(instance);
    ProtoPirateHistoryItemArray_clear(instance->data);
    protopirate_storage_wipe_history_cache();

    if(instance->scratch_text) {
        furi_string_free(instance->scratch_text);
        instance->scratch_text = NULL;
    }
    if(instance->scratch_path) {
        furi_string_free(instance->scratch_path);
        instance->scratch_path = NULL;
    }
    if(instance->text_arena) {
        furi_string_free(instance->text_arena);
        instance->text_arena = NULL;
    }

    if(instance->storage) {
        furi_record_close(RECORD_STORAGE);
        instance->storage = NULL;
    }
    furi_mutex_free(instance->mutex);
    free(instance);
}

void protopirate_history_reset(ProtoPirateHistory* instance) {
    HISTORY_GUARD(instance);
    furi_check(instance);
    protopirate_history_release_scratch(instance);
    protopirate_history_clear_all_matched(instance);
    ProtoPirateHistoryItemArray_reset(instance->data);
    furi_string_reset(instance->text_arena);
    instance->last_index = 0;
    protopirate_storage_wipe_history_cache();
}

uint16_t protopirate_history_get_item(ProtoPirateHistory* instance) {
    HISTORY_GUARD(instance);
    furi_check(instance);
    return ProtoPirateHistoryItemArray_size(instance->data);
}

uint16_t protopirate_history_get_last_index(ProtoPirateHistory* instance) {
    HISTORY_GUARD(instance);
    furi_check(instance);
    return instance->last_index;
}

void protopirate_history_format_status_text(
    ProtoPirateHistory* instance,
    char* output,
    size_t output_size) {
    HISTORY_GUARD(instance);
    furi_check(instance);
    furi_check(output);

    if(output_size == 0) {
        return;
    }

    uint16_t n = protopirate_history_get_item(instance);
    if(n >= PROTOPIRATE_HISTORY_MAX) {
        snprintf(output, output_size, "FULL");
    } else {
        snprintf(output, output_size, "%u/%u", n, PROTOPIRATE_HISTORY_MAX);
    }
}

void protopirate_history_get_status_text(ProtoPirateHistory* instance, FuriString* output) {
    HISTORY_GUARD(instance);
    furi_check(instance);
    furi_check(output);

    char status_text[16];
    protopirate_history_format_status_text(instance, status_text, sizeof(status_text));
    furi_string_set_str(output, status_text);
}

bool protopirate_history_get_capture_path(
    ProtoPirateHistory* instance,
    uint16_t idx,
    FuriString* out_path) {
    HISTORY_GUARD(instance);
    furi_check(instance);
    furi_check(out_path);

    if(idx >= ProtoPirateHistoryItemArray_size(instance->data)) {
        return false;
    }
    ProtoPirateHistoryItem* item = ProtoPirateHistoryItemArray_get(instance->data, idx);
    if(item->capture && !item->persisted) {
        /* UI-only: materialize a file only when a file path is requested. */
        if(!protopirate_storage_save_history_capture(item->capture, item->seq_id, out_path))
            return false;
        item->persisted = true;
    }
    protopirate_history_build_path(instance, item->seq_id, out_path);
    return true;
}

bool protopirate_history_capture_path_equals(
    ProtoPirateHistory* instance,
    uint16_t idx,
    const char* path) {
    HISTORY_GUARD(instance);
    furi_check(instance);

    if(!path || idx >= ProtoPirateHistoryItemArray_size(instance->data)) {
        return false;
    }

    ProtoPirateHistoryItem* item = ProtoPirateHistoryItemArray_get(instance->data, idx);
    protopirate_history_build_path(instance, item->seq_id, instance->scratch_path);
    return strcmp(furi_string_get_cstr(instance->scratch_path), path) == 0;
}

bool protopirate_history_add_to_history_at(
    ProtoPirateHistory* instance,
    void* context,
    SubGhzRadioPreset* preset,
    uint32_t update_timestamp) {
    HISTORY_GUARD(instance);
    furi_check(instance);
    furi_check(context);

    if(ProtoPirateHistoryItemArray_size(instance->data) >= PROTOPIRATE_HISTORY_MAX) {
        return false;
    }

    SubGhzProtocolDecoderBase* decoder_base = context;

    if((ProtoPirateHistoryItemArray_size(instance->data) > 0) &&
       (instance->code_last_hash_data ==
        subghz_protocol_decoder_base_get_hash_data(decoder_base)) &&
       ((update_timestamp - instance->last_update_timestamp) < HISTORY_DUPLICATE_WINDOW)) {
        instance->last_update_timestamp = update_timestamp;
        return false;
    }

    /* loaded_ff belongs to the UI until it releases/switches that reader.
     * A new RX must not close it while auto-save or saved-match is reading. */

    furi_string_reset(instance->scratch_text);
    furi_string_reset(instance->scratch_path);

    subghz_protocol_decoder_base_get_string(decoder_base, instance->scratch_text);

    FlipperFormat* temp_ff = flipper_format_string_alloc();
    furi_check(temp_ff);

    SubGhzProtocolStatus ser =
        subghz_protocol_decoder_base_serialize(decoder_base, temp_ff, preset);
    if(ser != SubGhzProtocolStatusOk) {
        FURI_LOG_E(TAG, "Serialize failed");
        flipper_format_free(temp_ff);
        return false;
    }

    if(stream_size(flipper_format_get_raw_stream(temp_ff)) > HISTORY_CAPTURE_MAX_BYTES ||
       furi_string_size(instance->scratch_text) > HISTORY_LABEL_MAX_BYTES) {
        FURI_LOG_E(TAG, "Capture exceeds bounded history capacity");
        flipper_format_free(temp_ff);
        return false;
    }
    uint32_t seq = instance->next_capture_seq++;
    if(!instance->memory_mode) {
        bool saved = protopirate_storage_save_history_capture(temp_ff, seq, instance->scratch_path);
        flipper_format_free(temp_ff);
        temp_ff = NULL;
        if(!saved) {
            FURI_LOG_E(TAG, "Failed to save history file");
            return false;
        }
    }

    instance->code_last_hash_data = subghz_protocol_decoder_base_get_hash_data(decoder_base);
    instance->last_update_timestamp = update_timestamp;

    const char* text_cstr = furi_string_get_cstr(instance->scratch_text);
    size_t text_len = furi_string_size(instance->scratch_text);
    size_t offset = furi_string_size(instance->text_arena);
    furi_check(text_len <= UINT16_MAX);
    furi_check(offset <= UINT16_MAX);
    furi_string_cat_str(instance->text_arena, text_cstr);

    ProtoPirateHistoryItem* item = ProtoPirateHistoryItemArray_push_raw(instance->data);
    item->seq_id = seq;
    item->capture = temp_ff;
    item->persisted = !instance->memory_mode;
    item->text_offset = (uint16_t)offset;
    item->text_len = (uint16_t)text_len;
    item->type = 0;
    item->saved_match_state = ProtoPirateSavedMatchStateNone;
    item->auto_save_state = ProtoPirateAutoSaveStateNone;
    item->matched_saved_path = NULL;
    item->matched_name = NULL;

    instance->last_index++;

    FURI_LOG_I(
        TAG,
        "Added item %u to history (size: %zu) seq=%lu",
        instance->last_index,
        ProtoPirateHistoryItemArray_size(instance->data),
        (unsigned long)seq);

    return true;
}

bool protopirate_history_add_to_history(
    ProtoPirateHistory* instance,
    void* context,
    SubGhzRadioPreset* preset) {
    HISTORY_GUARD(instance);
    return protopirate_history_add_to_history_at(instance, context, preset, furi_get_tick());
}

void protopirate_history_delete_item(ProtoPirateHistory* instance, uint16_t idx) {
    HISTORY_GUARD(instance);
    furi_check(instance);

    size_t item_count = ProtoPirateHistoryItemArray_size(instance->data);
    if(idx >= item_count) {
        return;
    }

    if(instance->loaded_ff) {
        if(instance->loaded_idx == (int16_t)idx) {
            protopirate_history_release_scratch(instance);
        } else if(instance->loaded_idx > (int16_t)idx) {
            instance->loaded_idx--;
        }
    }

    ProtoPirateHistoryItem* item = ProtoPirateHistoryItemArray_get(instance->data, idx);
    uint32_t seq_id = item->seq_id;
    uint16_t text_offset = item->text_offset;
    uint16_t text_len = item->text_len;

    protopirate_history_item_clear_matched(item);
    if(item->persisted) protopirate_history_delete_capture_file(instance, seq_id);
    ProtoPirateHistoryItemArray_pop_at(NULL, instance->data, idx);
    protopirate_history_arena_remove(instance, text_offset, text_len);

    FURI_LOG_I(
        TAG,
        "Deleted history item %u (size: %zu)",
        idx,
        ProtoPirateHistoryItemArray_size(instance->data));
}

void protopirate_history_get_text_item_menu(
    ProtoPirateHistory* instance,
    FuriString* output,
    uint16_t idx) {
    HISTORY_GUARD(instance);
    furi_check(instance);
    furi_check(output);

    if(idx >= ProtoPirateHistoryItemArray_size(instance->data)) {
        furi_string_set(output, "---");
        return;
    }

    ProtoPirateHistoryItem* item = ProtoPirateHistoryItemArray_get(instance->data, idx);
    const char* arena = furi_string_get_cstr(instance->text_arena);
    const char* str = arena + item->text_offset;
    size_t remaining = item->text_len;

    size_t len = 0;
    while(len < remaining && str[len] != '\r' && str[len] != '\n') {
        len++;
    }

    uint16_t display_idx = idx + 1;
    furi_string_printf(output, "%u. %.*s", display_idx, (int)len, str);
}

void protopirate_history_get_text_item_detail(
    ProtoPirateHistory* instance,
    uint16_t idx,
    FuriString* output,
    SubGhzEnvironment* environment) {
    HISTORY_GUARD(instance);
    furi_check(instance);
    furi_check(output);
    UNUSED(environment);

    if(idx >= ProtoPirateHistoryItemArray_size(instance->data)) {
        furi_string_set(output, "---");
        return;
    }

    ProtoPirateHistoryItem* item = ProtoPirateHistoryItemArray_get(instance->data, idx);
    const char* arena = furi_string_get_cstr(instance->text_arena);
    furi_string_set_strn(output, arena + item->text_offset, item->text_len);
}

FlipperFormat* protopirate_history_get_raw_data(ProtoPirateHistory* instance, uint16_t idx) {
    HISTORY_GUARD(instance);
    furi_check(instance);

    if(idx >= ProtoPirateHistoryItemArray_size(instance->data)) {
        return NULL;
    }

    if(instance->loaded_idx == (int16_t)idx && instance->loaded_ff) {
        return instance->loaded_ff;
    }

    protopirate_history_release_scratch(instance);

    ProtoPirateHistoryItem* item = ProtoPirateHistoryItemArray_get(instance->data, idx);
    if(item->capture) {
        instance->loaded_ff = flipper_format_string_alloc();
        if(!instance->loaded_ff) return NULL;
        Stream* source = flipper_format_get_raw_stream(item->capture);
        Stream* dest = flipper_format_get_raw_stream(instance->loaded_ff);
        size_t size = stream_size(source);
        if(!stream_seek(source, 0, StreamOffsetFromStart) ||
           !stream_seek(dest, 0, StreamOffsetFromStart) || stream_copy(source, dest, size) != size) {
            flipper_format_free(instance->loaded_ff);
            instance->loaded_ff = NULL;
            return NULL;
        }
        flipper_format_rewind(instance->loaded_ff);
        instance->loaded_idx = (int16_t)idx;
        return instance->loaded_ff;
    }
    protopirate_history_build_path(instance, item->seq_id, instance->scratch_path);

    instance->loaded_ff = flipper_format_file_alloc(instance->storage);
    furi_check(instance->loaded_ff);
    if(!flipper_format_file_open_existing(
           instance->loaded_ff, furi_string_get_cstr(instance->scratch_path))) {
        FURI_LOG_E(
            TAG, "Failed open history capture %s", furi_string_get_cstr(instance->scratch_path));
        flipper_format_free(instance->loaded_ff);
        instance->loaded_ff = NULL;
        return NULL;
    }
    instance->loaded_idx = (int16_t)idx;
    return instance->loaded_ff;
}

void protopirate_history_set_matched_saved(
    ProtoPirateHistory* instance,
    uint16_t idx,
    const char* name,
    const char* path) {
    HISTORY_GUARD(instance);
    furi_check(instance);

    if(idx >= ProtoPirateHistoryItemArray_size(instance->data)) {
        return;
    }

    ProtoPirateHistoryItem* item = ProtoPirateHistoryItemArray_get(instance->data, idx);

    if(!item->matched_name) item->matched_name = furi_string_alloc();
    if(!item->matched_saved_path) item->matched_saved_path = furi_string_alloc();

    furi_string_set_str(item->matched_name, name ? name : "");
    furi_string_set_str(item->matched_saved_path, path ? path : "");
    item->saved_match_state = ProtoPirateSavedMatchStateDone;
}

const char*
    protopirate_history_get_matched_saved_path(ProtoPirateHistory* instance, uint16_t idx) {
    HISTORY_GUARD(instance);
    furi_check(instance);

    if(idx >= ProtoPirateHistoryItemArray_size(instance->data)) {
        return NULL;
    }

    ProtoPirateHistoryItem* item = ProtoPirateHistoryItemArray_get(instance->data, idx);
    if(!item->matched_saved_path || furi_string_size(item->matched_saved_path) == 0) {
        return NULL;
    }
    return furi_string_get_cstr(item->matched_saved_path);
}

const char* protopirate_history_get_matched_name(ProtoPirateHistory* instance, uint16_t idx) {
    HISTORY_GUARD(instance);
    furi_check(instance);

    if(idx >= ProtoPirateHistoryItemArray_size(instance->data)) {
        return NULL;
    }

    ProtoPirateHistoryItem* item = ProtoPirateHistoryItemArray_get(instance->data, idx);
    if(!item->matched_name || furi_string_size(item->matched_name) == 0) {
        return NULL;
    }
    return furi_string_get_cstr(item->matched_name);
}

bool protopirate_history_has_matched_saved(ProtoPirateHistory* instance, uint16_t idx) {
    HISTORY_GUARD(instance);
    return protopirate_history_get_matched_saved_path(instance, idx) != NULL;
}

void protopirate_history_mark_auto_save_pending(ProtoPirateHistory* instance, uint16_t idx) {
    HISTORY_GUARD(instance);
    furi_check(instance);

    if(idx >= ProtoPirateHistoryItemArray_size(instance->data)) {
        return;
    }

    ProtoPirateHistoryItem* item = ProtoPirateHistoryItemArray_get(instance->data, idx);
    item->auto_save_state = ProtoPirateAutoSaveStatePending;
}

bool protopirate_history_find_pending_auto_save(ProtoPirateHistory* instance, uint16_t* idx) {
    HISTORY_GUARD(instance);
    furi_check(instance);
    furi_check(idx);

    const size_t item_count = ProtoPirateHistoryItemArray_size(instance->data);
    for(size_t i = 0; i < item_count; i++) {
        ProtoPirateHistoryItem* item = ProtoPirateHistoryItemArray_get(instance->data, i);
        if(item->auto_save_state == ProtoPirateAutoSaveStatePending) {
            *idx = (uint16_t)i;
            return true;
        }
    }
    return false;
}

void protopirate_history_mark_auto_save_done(ProtoPirateHistory* instance, uint16_t idx) {
    HISTORY_GUARD(instance);
    furi_check(instance);

    if(idx >= ProtoPirateHistoryItemArray_size(instance->data)) {
        return;
    }

    ProtoPirateHistoryItem* item = ProtoPirateHistoryItemArray_get(instance->data, idx);
    item->auto_save_state = ProtoPirateAutoSaveStateDone;
}

void protopirate_history_mark_saved_match_pending(ProtoPirateHistory* instance, uint16_t idx) {
    HISTORY_GUARD(instance);
    furi_check(instance);

    if(idx >= ProtoPirateHistoryItemArray_size(instance->data)) {
        return;
    }

    ProtoPirateHistoryItem* item = ProtoPirateHistoryItemArray_get(instance->data, idx);
    item->saved_match_state = ProtoPirateSavedMatchStatePending;
}

bool protopirate_history_find_pending_saved_match(ProtoPirateHistory* instance, uint16_t* idx) {
    HISTORY_GUARD(instance);
    furi_check(instance);
    furi_check(idx);

    const size_t item_count = ProtoPirateHistoryItemArray_size(instance->data);
    for(size_t i = 0; i < item_count; i++) {
        ProtoPirateHistoryItem* item = ProtoPirateHistoryItemArray_get(instance->data, i);
        if(item->saved_match_state == ProtoPirateSavedMatchStatePending) {
            *idx = (uint16_t)i;
            return true;
        }
    }
    return false;
}

void protopirate_history_mark_saved_match_done(ProtoPirateHistory* instance, uint16_t idx) {
    HISTORY_GUARD(instance);
    furi_check(instance);

    if(idx >= ProtoPirateHistoryItemArray_size(instance->data)) {
        return;
    }

    ProtoPirateHistoryItem* item = ProtoPirateHistoryItemArray_get(instance->data, idx);
    item->saved_match_state = ProtoPirateSavedMatchStateDone;
}

void protopirate_history_set_item_str(ProtoPirateHistory* instance, uint16_t idx, const char* str) {
    HISTORY_GUARD(instance);
    furi_check(instance);
    furi_check(str);

    if(idx >= ProtoPirateHistoryItemArray_size(instance->data)) {
        return;
    }

    ProtoPirateHistoryItem* item = ProtoPirateHistoryItemArray_get(instance->data, idx);
    uint16_t old_offset = item->text_offset;
    uint16_t old_len = item->text_len;

    protopirate_history_arena_remove(instance, old_offset, old_len);

    size_t new_offset = furi_string_size(instance->text_arena);
    size_t new_len = strlen(str);
    furi_check(new_offset <= UINT16_MAX);
    furi_check(new_len <= UINT16_MAX);
    furi_string_cat_str(instance->text_arena, str);
    item->text_offset = (uint16_t)new_offset;
    item->text_len = (uint16_t)new_len;
}
