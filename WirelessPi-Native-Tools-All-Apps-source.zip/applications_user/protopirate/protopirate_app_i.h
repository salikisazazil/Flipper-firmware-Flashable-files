// protopirate_app_i.h
#pragma once

#include <stddef.h>
#include "helpers/protopirate_types.h"
#include "scenes/protopirate_scene.h"
#include "views/protopirate_receiver.h"
#include "protopirate_history.h"
#include "helpers/radio_device_loader.h"

#include <gui/gui.h>
#include <gui/view_dispatcher.h>
#include <gui/scene_manager.h>
#include <gui/modules/submenu.h>

#include <gui/modules/widget.h>
#include <gui/modules/text_input.h>
#include <notification/notification_messages.h>
#include <lib/subghz/subghz_setting.h>
#include <lib/subghz/subghz_worker.h>
#include <lib/subghz/receiver.h>
#include <lib/subghz/transmitter.h>
#include <lib/subghz/devices/devices.h>
#include <lib/subghz/subghz_file_encoder_worker.h>
#include <dialogs/dialogs.h>
#include "defines.h"
#include "protocols/protocols_common.h"
#include "protocols/protocol_items.h"
#include "protocols/protopirate_protocol_plugins.h"
#ifdef ENABLE_EMULATE_FEATURE
#include "scenes/plugins/protopirate_emulate_plugin.h"
#endif
#include "scenes/plugins/protopirate_config_plugin.h"
#include "scenes/plugins/protopirate_saved_info_plugin.h"
#include "scenes/plugins/protopirate_about_plugin.h"
#include "scenes/plugins/protopirate_psa_bf_plugin.h"
#include "scenes/plugins/protopirate_tool_scene_plugin.h"
#include "helpers/protopirate_plugins.h"
#include "helpers/protopirate_views.h"
#include "helpers/protopirate_radio.h"
#include "helpers/protopirate_protocol_plugin_host.h"
#include "helpers/protopirate_txrx.h"
#include "helpers/protopirate_models.h"
#include "helpers/protopirate_settings.h"

#ifdef ENABLE_MODELS_DATABASE
#define PROTOPIRATE_KEYSTORE_DIR_NAME APP_ASSETS_PATH("keystore/encrypted")
#else
#define PROTOPIRATE_KEYSTORE_DIR_NAME APP_ASSETS_PATH("encrypted")
#endif

typedef struct VariableItemList VariableItemList;

typedef struct ProtoPirateTxRx {
    SubGhzWorker* worker;
    SubGhzEnvironment* environment;
    SubGhzReceiver* receiver;
    SubGhzRadioPreset* preset;
    const SubGhzProtocolRegistry* protocol_registry;
    FlipperApplication* protocol_plugin_flipper_application;
    const ProtoPirateProtocolPlugin* protocol_plugin;
    ProtoPirateProtocolRegistryRoute protocol_registry_route;
    ProtoPirateHistory* history;
    const SubGhzDevice* radio_device;
    ProtoPirateTxRxState txrx_state;
    ProtoPirateHopperState hopper_state;
    ProtoPirateRxKeyState rx_key_state;
    uint8_t hopper_idx_frequency;
    uint8_t hopper_timeout;
    uint16_t idx_menu_chosen;
} ProtoPirateTxRx;

typedef struct ProtoPirateConfigPlugin ProtoPirateConfigPlugin;
typedef struct {
    char label[32];
    ButtonCallback callback;
    void* context;
    GuiButtonType button;
    uint32_t event;
} ProtoPirateAction;

struct ProtoPirateApp {
    Gui* gui;
    ViewDispatcher* view_dispatcher;
    SceneManager* scene_manager;
    NotificationApp* notifications;
    DialogsApp* dialogs;
    VariableItemList* variable_item_list;
    Submenu* submenu;
    Submenu* actions_menu;
    ProtoPirateAction actions[3];
    uint8_t action_count;
    bool actions_visible;
    uint32_t actions_return_view;
    Widget* widget;
    TextInput* text_input;
    View* view_about;
    char* file_path;
    ProtoPirateReceiver* protopirate_receiver;
    uint32_t deferred_storage_deadline;
    bool deferred_storage_pending;
    uint32_t receiver_update_pending;
    ProtoPirateTxRx* txrx;
    SubGhzSetting* setting;
    ProtoPirateLock lock;
    char* loaded_file_path;
    /*****************/
    // Byte 1
    uint8_t deferred_storage_in_progress : 1;
    uint8_t auto_save                    : 1;
    uint8_t check_saved                  : 1;
    uint8_t sound                        : 1;
    uint8_t datetime_filenames           : 1;
    uint8_t radio_initialized            : 1;
    uint8_t emulate_disabled_for_loaded  : 1;
    uint8_t emulate_feature_enabled      : 1;
    // Byte 2
    uint8_t key_found                    : 1;
    uint8_t reserved                     : 7;
    /*****************/
    uint32_t start_tx_time;
    uint8_t tx_power;
    char save_filename[64];
    FuriString* save_protocol;
    uint16_t save_history_idx;
    bool receiver_info_editing;
    FlipperApplication* plugin_flipper_application;
#ifdef ENABLE_EMULATE_FEATURE
    const ProtoPirateEmulatePlugin* emulate_plugin;
    uint8_t emulate_nav_pending;
#endif
    const ProtoPirateConfigPlugin* config_plugin;
    const ProtoPirateSavedInfoPlugin* saved_info_plugin;
    const ProtoPirateAboutPlugin* about_plugin;
    FlipperApplication* psa_bf_plugin_flipper_application;
    const ProtoPiratePsaBfPlugin* psa_bf_plugin;
    FlipperApplication* tool_scene_plugin_flipper_application;
    const ProtoPirateToolScenePlugin* tool_scene_plugin;
    ProtoPirateToolScenePluginKind tool_scene_plugin_kind;
#ifdef ENABLE_MODELS_DATABASE
    ProtoPirateCarModel* selected_model;
    uint16_t car_models_count;
#endif
};

#ifdef ENABLE_EMULATE_FEATURE
void protopirate_emulate_context_release(ProtoPirateApp* app);
#endif

typedef enum {
    ProtoPirateSetTypeFord_v0,
    ProtoPirateSetTypeMAX,
} ProtoPirateSetType;

bool protopirate_tool_scene_on_enter(void* app, ProtoPirateToolScenePluginKind kind);
bool protopirate_tool_scene_on_event(void* app, SceneManagerEvent event);
void protopirate_tool_scene_on_exit(void* app);
void protopirate_tool_scene_plugin_release(ProtoPirateApp* app);
void protopirate_app_free(ProtoPirateApp* app);

static const NotificationSequence sequence_tx = {
    &message_note_c5,
    &message_vibro_on,
    &message_red_255,
    &message_blue_255,
    &message_blink_start_10,
    &message_delay_25,
    &message_vibro_off,
    &message_delay_25,
    &message_sound_off,
    NULL,
};

#include "helpers/protopirate_actions.h"
